/**
 * Admin utilities for Lambda functions
 */

/**
 * Check if an email is an admin email
 * @param {string} email - Email to check
 * @returns {boolean} - True if email is admin
 */
function isAdminEmail(email) {
  const adminEmails = (process.env.ADMIN_EMAILS || '')
    .split(',')
    .map(e => e.trim())
    .filter(e => e.length > 0);
  
  return adminEmails.includes(email);
}

/**
 * Get list of admin emails
 * @returns {string[]} - Array of admin emails
 */
function getAdminEmails() {
  return (process.env.ADMIN_EMAILS || '')
    .split(',')
    .map(e => e.trim())
    .filter(e => e.length > 0);
}

module.exports = {
  isAdminEmail,
  getAdminEmails,
};
